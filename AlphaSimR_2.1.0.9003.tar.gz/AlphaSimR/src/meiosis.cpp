#include "alphasimr.h"

namespace {

// Creates one stable dqrng substream per chromosome for the current call.
// Stream ids follow chromosome order so results stay reproducible if the
// OpenMP thread count changes.
std::vector<alphasimrRng::rngPtr> makeChrRngs(arma::uword nChr) {
  dqrng::rng64_t baseRng = alphasimrRng::createRng();
  std::vector<alphasimrRng::rngPtr> chrRngs;
  chrRngs.reserve(nChr);
  for (arma::uword chr = 0; chr < nChr; ++chr) {
    // One stable dqrng substream per chromosome keeps meiosis reproducible
    // even when the OpenMP thread count changes.
    chrRngs.push_back(alphasimrRng::cloneStream(baseRng, chr + 1));
  }
  return chrRngs;
}

} // namespace

// Class for storing recombination history
class RecHist{
public:
  arma::field< //individual
    arma::field< //chromosome
      arma::field< //ploidy
        arma::Mat<int> > > > hist; //(chr, site)
  
  // Allocates space for history
  void setSize(arma::uword nInd, 
               arma::uword nChr, 
               arma::uword ploidy);
  
  // Append new recombination history
  void addHist(arma::Mat<int>& input, 
               arma::uword nInd, 
               arma::uword chrGroup,
               arma::uword chrInd);
  
  // Access history
  arma::Mat<int> getHist(arma::uword ind, 
                         arma::uword chr,
                         arma::uword par);
};

// Allocates space for history
void RecHist::setSize(arma::uword nInd, 
                      arma::uword nChr, 
                      arma::uword ploidy=2){
  hist.set_size(nInd);
  for(arma::uword i=0; i<nInd; ++i){
    hist(i).set_size(nChr);
    for(arma::uword j=0; j<nChr; ++j){
      hist(i)(j).set_size(ploidy);
    }
  }
}

// Append new recombination history
void RecHist::addHist(arma::Mat<int>& input, 
             arma::uword nInd, 
             arma::uword chrGroup,
             arma::uword chrInd){
  hist(nInd)(chrGroup)(chrInd) = input;
}

// Access history
arma::Mat<int> RecHist::getHist(arma::uword ind, 
                                arma::uword chr,
                                arma::uword par){
  return hist(ind)(chr)(par);
}

// Like RecHist, but store double positions (e.g., genetic coordinate)
class RecHistDbl{
public:
  arma::field< //individual
    arma::field< //chromosome
      arma::field< //ploidy
        arma::Mat<double> > > > hist; //(chr, posGen)

  void setSize(arma::uword nInd,
               arma::uword nChr,
               arma::uword ploidy);

  void addHist(arma::Mat<double>& input,
               arma::uword nInd,
               arma::uword chrGroup,
               arma::uword chrInd);

  arma::Mat<double> getHist(arma::uword ind,
                            arma::uword chr,
                            arma::uword par);
};

void RecHistDbl::setSize(arma::uword nInd,
                         arma::uword nChr,
                         arma::uword ploidy=2){
  hist.set_size(nInd);
  for(arma::uword i=0; i<nInd; ++i){
    hist(i).set_size(nChr);
    for(arma::uword j=0; j<nChr; ++j){
      hist(i)(j).set_size(ploidy);
    }
  }
}

void RecHistDbl::addHist(arma::Mat<double>& input,
                         arma::uword nInd,
                         arma::uword chrGroup,
                         arma::uword chrInd){
  hist(nInd)(chrGroup)(chrInd) = input;
}

arma::Mat<double> RecHistDbl::getHist(arma::uword ind,
                                      arma::uword chr,
                                      arma::uword par){
  return hist(ind)(chr)(par);
}

// Samples the locations for chiasmata via a gamma process
// end, the length of the interval used to sample
// v, the interference parameter
// p, the proportion of non-interfering crossovers
// rng, the explicit dqrng stream used for all random draws in this call
// n, the number of gamma deviates sampled at a time (affects performance, not results)
arma::vec sampleChiasmata(double end, double v, 
                          double p, alphasimrRng::rngEngine& rng,
                          arma::uword n=40){
  if((1.0-p)<1.0e-6){
    // No crossover interference
    // Switching to count-location model
    n = alphasimrRng::samplePoisson(2.0*end, rng);
    arma::vec x = alphasimrRng::runifVec(n, rng);
    return sort(x);
    
  }else{
    // Using gamma or gamma-sprinkling model
    
    // Choose a starting location 9-10 Morgans away
    double start = alphasimrRng::runif(rng) - 10.0;
    
    if(p<1.0e-6){ // Gamma model
      // Sample deviates from a gamma distribution
      arma::vec output = alphasimrRng::rgammaVec(n, v, 1.0/(2.0*v), rng);
      
      // Find locations on genetic map
      output = cumsum(output)+start;
      
      // Add additional values if max position less than end
      while(output(output.n_elem-1)<end){
        arma::vec tmp = alphasimrRng::rgammaVec(n, v, 1.0/(2.0*v), rng);
        tmp = cumsum(tmp) + output(output.n_elem-1);
        output = join_cols(output, tmp);
      }
      
      // Remove values less than 0
      output = output(find(output>0));
      
      // Select values less than the end
      return output(find(output<end));
    }else{ // Gamma sprinkling model
      // Sample type 1 deviates from a gamma distribution
      arma::vec type1 = alphasimrRng::rgammaVec(
        n, v, 1.0/(2.0*v*(1.0-p)), rng);
      
      // Find locations on genetic map
      type1 = cumsum(type1)+start;
      
      // Add additional values if max position less than end
      while(type1(type1.n_elem-1)<end){
        arma::vec tmp = alphasimrRng::rgammaVec(
          n, v, 1.0/(2.0*v*(1.0-p)), rng);
        tmp = cumsum(tmp) + type1(type1.n_elem-1);
        type1 = join_cols(type1, tmp);
      }
      
      // Remove values less than 0
      type1 = type1(find(type1>0));
      
      // Select values less than the end
      type1 = type1(find(type1<end));
      
      // Sample type 2 deviates from a gamma distribution
      arma::vec type2 = alphasimrRng::rgammaVec(
        n, 1.0, 1.0/(2.0*p), rng);
      
      // Find locations on genetic map
      type2 = cumsum(type2);
      
      // Add additional values if max position less than end
      while(type2(type2.n_elem-1)<end){
        arma::vec tmp = alphasimrRng::rgammaVec(
          n, 1.0, 1.0/(2.0*p), rng);
        tmp = cumsum(tmp) + type2(type2.n_elem-1);
        type2 = join_cols(type2, tmp);
      }
      
      // Select values less than the end
      type2 = type2(find(type2<end));
      
      // Return sorted vector of type 1 and type 2 crossovers
      return sort(join_cols(type1, type2));
    }
  }
}

// Samples the locations for chiasmata via a gamma process for a quadrivalent
// CO interference is assumed to occur between all arms
// The first arm is sampled at random
// exchange, the positions where chromosomes switch
// end, the length of the interval used to sample
// v, the interference parameter
// p, the proportion of non-interfering crossovers
// rng, the explicit dqrng stream used for all random draws in this call
// n1, the number of gamma deviates sampled for the first arm 
// n2, the number of gamma deviates sampled for all other arms
arma::field<arma::vec> sampleQuadChiasmata(double exchange, double end, double v, 
                                           double p, alphasimrRng::rngEngine& rng,
                                           arma::uword n1=40, arma::uword n2=8){
  arma::field<arma::vec> output(4);
  double start = alphasimrRng::runif(rng) - 10.0;
  
  // Randomly set order of chromosome arms
  arma::uvec arm = {0, 1, 2, 3};
  alphasimrRng::shuffle(arm, rng);
  double nearest, terminator, prob;
  
  if((1.0-p)<1.0e-6){
    // All chiasmata from type 2 pathway
    // Changing v and p to model type 2 with type 1 pathway
    p = 0.0;
    v = 1.0;
  }
  
  // First arm
  output(arm(0)) = alphasimrRng::rgammaVec(n1, v, 1.0/(2.0*v*(1.0-p)), rng);
  output(arm(0)) = cumsum(output(arm(0))) + start;
  if(arm(0)%2){ // Tail
    terminator = end - exchange;
  }else{ // Head
    terminator = exchange;
  }
  while( output(arm(0))(output(arm(0)).n_elem-1) < terminator ){
    arma::vec tmp = alphasimrRng::rgammaVec(n2, v, 1.0/(2.0*v*(1.0-p)), rng);
    tmp = cumsum(tmp) + output(arm(0))(output(arm(0)).n_elem-1);
    output(arm(0)) = join_cols(output(arm(0)), tmp);
  }
  output(arm(0)) = output(arm(0))(find(output(arm(0))<terminator));
  nearest = terminator - output(arm(0))(output(arm(0)).n_elem-1);
  output(arm(0)) = output(arm(0))(find(output(arm(0))>0));
  if(arm(0)%2){ // Tail
    output(arm(0)) = sort(end-output(arm(0)));
  }
  
  // All other arms
  for(arma::uword i=1; i<4; ++i){
    output(arm(i)).set_size(1+n2);
    prob = R::pgamma(nearest, v, 1.0/(2.0*v*(1.0-p)), 1, 0);
    double u = alphasimrRng::runif(rng);
    u = u*(1.0-prob)+prob;
    output(arm(i))(0) = R::qgamma(u, v, 1.0/(2.0*v*(1.0-p)), 1, 0) - nearest;
    if(output(arm(i))(0) < nearest){
      nearest = output(arm(i))(0);
    }
    output(arm(i))(arma::span(1,n2)) = alphasimrRng::rgammaVec(
      n2, v, 1.0/(2.0*v*(1.0-p)), rng);
    output(arm(i)) = cumsum(output(arm(i)));
    if(arm(i)%2){ // Tail
      terminator = end - exchange;
    }else{ // Head
      terminator = exchange;
    }
    while( output(arm(i))(output(arm(i)).n_elem-1) < terminator ){
      arma::vec tmp = alphasimrRng::rgammaVec(n2, v, 1.0/(2.0*v*(1.0-p)), rng);
      tmp = cumsum(tmp) + output(arm(i))(output(arm(i)).n_elem-1);
      output(arm(i)) = join_cols(output(arm(i)), tmp);
    }
    output(arm(i)) = output(arm(i))(find(output(arm(i))<terminator));
    if(arm(i)%2){ // Tail
      output(arm(i)) += exchange;
    }else{ // Head
      output(arm(i)) = sort(exchange-output(arm(i)));
    }
  }
  
  if(p>1.0e-6){ // Sprinkle recombinations
    for(arma::uword i=0; i<4; ++i){
      if(arm(i)%2){ // Tail
        terminator = end - exchange;
      }else{ // Head
        terminator = exchange;
      }
      
      // Sample type 2 deviates from a gamma distribution
      arma::vec type2 = alphasimrRng::rgammaVec(n2, 1.0, 1.0/(2.0*p), rng);
      
      // Find locations on genetic map
      type2 = cumsum(type2);
      
      // Add additional values if max position less than terminator
      while(type2(type2.n_elem-1)<terminator){
        arma::vec tmp = alphasimrRng::rgammaVec(n2, 1.0, 1.0/(2.0*p), rng);
        tmp = cumsum(tmp) + type2(type2.n_elem-1);
        type2 = join_cols(type2, tmp);
      }
      
      // Select values less than the end
      type2 = type2(find(type2<terminator));
      
      // Add exchange to genetic position if in tail
      if(arm(i)%2){ // Tail
        type2 += exchange;
      }
      
      // Combine type 1 and 2 crossovers and sort
      output(arm(i)) = sort(join_cols(output(arm(i)), type2));
    }
  }
  
  return output;
}


// Searches for an interval in x containing value
// Result reported as left most element of the interval
// Returns an error if value is smaller than the values of x
// Returns last element if value is greater than values of x
// Set left to the smallest value of the interval to search
arma::uword intervalSearch(const arma::vec& x, double& value, arma::uword left=0){
  // Check if crossover is before beginning
  if(x[left]>value){
    Rcpp::stop("intervalSearch searching in impossible interval");
  }
  arma::uword end = x.n_elem-1;
  
  // Check if crossover is at or past end
  if(x[end]<=value){
    return end;
  }
  
  // Perform search
  arma::uword right = end;
  while((right-left)>1){ // Interval can be decreased
    arma::uword middle = (left + right) / 2;
    if (x[middle] == value){
      left = middle;
      
      // Check if at the end of the vector
      if(left<end){
        // Check for identical values to the right
        while(x[left+1]==value){
          left += 1;
          if(left==end){
            break;
          }
        }
      }
      break;
    } else if (x[middle]>value){
      right = middle;
    }else{
      left = middle;
    }
  }
  return left;
}

// Removes hidden crossovers from recombination map
// Assumes first row is always site 1 and no other row
// will have a value of 1. This logic is based on 
// the implementation of intervalSearch.
arma::Mat<int> removeDoubleCO(const arma::Mat<int>& X){
  if(X.n_rows<3){
    return X;
  }
  
  // Initially assume all rows are useful
  arma::Col<int> take(X.n_rows,arma::fill::ones);
  
  // Remove unobserved crossovers (site doesn't change)
  // Works backwards, because the last crossover is observed
  for(arma::uword i=(X.n_rows-2); i>0; --i){
    if(X(i,1) == X(i+1,1)){
      take(i) = 0;
    }
  }
  
  // Remove redundant records (chromosome doesn't change)
  int lastChr = X(0,0);
  for(arma::uword i=1; i<X.n_rows; ++i){
    if(take(i) == 1){
      if(X(i,0) == lastChr){
        take(i) = 0;
      }else{
        lastChr = X(i,0);
      }
    }
  }
  return X.rows(find(take>0));
}

// Finds recombination map for a bivalent pair
// genMap, chromosome genetic map
// v, the interference parameter
// p, the proportion of non-interfering crossovers
// rng, the explicit dqrng stream used for all random draws in this call
arma::Mat<int> findBivalentCO(const arma::vec& genMap, double v, double p,
                              alphasimrRng::rngEngine& rng){
  arma::uword startPos=0, endPos, readChr=0, nCO;
  double genLen = genMap(genMap.n_elem-1);
  
  // Find crossover positions
  arma::vec posCO = sampleChiasmata(genLen, v, p, rng);
  if(posCO.n_elem==0){
    arma::Mat<int> output(1,2,arma::fill::ones);
    return output;
  }
  
  // Thin crossovers 
  arma::vec thin = alphasimrRng::runifVec(posCO.n_elem, rng);
  posCO = posCO(find(thin>0.5));
  nCO = posCO.n_elem;
  
  arma::Mat<int> output(nCO+1,2);
  if(nCO==0){
    output.ones();
    return output;
  }
  
  // Find crossover sites on map
  output.row(0).ones();
  for(arma::uword i=0; i<nCO; ++i){
    ++readChr;
    readChr = readChr%2;
    endPos = intervalSearch(genMap,posCO(i),startPos);
    output(i+1,0) = readChr+1;
    output(i+1,1) = endPos+2;
    startPos = endPos;
  }
  
  return removeDoubleCO(output);
}

// Continuous (genetic-coordinate) recombination history for a bivalent pair
// Output columns: (originChr, startPosGen)
// Row 0 is always (1, 0.0)
arma::Mat<double> findBivalentCO_gen(const arma::vec& genMap, double v, double p,
                                     alphasimrRng::rngEngine& rng){
  arma::uword readChr = 0;
  double genLen = genMap(genMap.n_elem-1);

  // 1) Sample crossover positions on the genetic map
  arma::vec posCO = sampleChiasmata(genLen, v, p, rng);

  // If no chiasmata were sampled: return a single record (all from chr1)
  if(posCO.n_elem==0){
    arma::Mat<double> output(1,2);
    output(0,0) = 1.0;  // origin chr1
    output(0,1) = 0.0;  // start at beginning of chromosome (continuous)
    return output;
  }

  // 2）Thin crossovers
  arma::vec thin = alphasimrRng::runifVec(posCO.n_elem, rng);
  posCO = posCO(find(thin>0.5));

  arma::uword nCO = posCO.n_elem;

  arma::Mat<double> output(nCO+1, 2);

  // 3） Allocate output
  output(0,0) = 1.0;
  output(0,1) = 0.0;

  if(nCO==0){
    return output;
  }

  posCO = sort(posCO);

  // 4) Alternate origin each crossover
  for(arma::uword i=0; i<nCO; ++i){
    ++readChr;
    readChr = readChr%2;
    output(i+1, 0) = double(readChr + 1);
    output(i+1, 1) = posCO(i);
  }

  return output;
}


/*
 * Finds recombination maps for a quadrivalent "cross-type" configuration
 * The configuration for chromosome pairing is as follows:
 *  Arm 0: chromosome heads 1 and 2
 *  Arm 1: chromosome tail 2 and 3
 *  Arm 2: chromosome heads 3 and 4
 *  Arm 3: chromosome tails 1 and 4
 * The exchange point between pairings is sampled at random
 * A centromere from the first chromosome is always selected
 * The second centromere is sampled at random
 * rng is the explicit dqrng stream used for all random draws in this call
 */
arma::field<arma::Mat<int> > findQuadrivalentCO(const arma::vec& genMap,
                                                double centromere, double v,
                                                double p,
                                                alphasimrRng::rngEngine& rng){
  arma::field<arma::Mat<int> > output(2);
  double genLen = genMap(genMap.n_elem-1);
  
  // Sample the exchange point
  double exchange = alphasimrRng::runif(rng) * genLen;
  
  // Determine crossover positions
  // Returns field with crossover positions in each arm of the quadrivalent
  arma::field<arma::vec> posCO = sampleQuadChiasmata(exchange, genLen, v, p, rng);
  
  // Set chromatid configuration for each chiasmata
  arma::field<arma::umat> chromatidPairs(4); // matches posCO
  for(arma::uword i=0; i<4; ++i){
    // Create table for chromatid pairs on an arm
    chromatidPairs(i).set_size(posCO(i).n_elem,2);
    
    // Assign pairs if there are chiasmata
    if(chromatidPairs(i).n_rows>0){
      // Initializing with "0" chromatid
      chromatidPairs(i).zeros();
      
      // Randomly switch to "1" chromatid
      for(arma::uword j=0; j<chromatidPairs(i).n_elem; ++j){
        if(alphasimrRng::runif(rng)>0.5){
          chromatidPairs(i).at(j) = 1;
        }
      }
    }
    
  }
  
  // Allocate output with a naive maximum number of COs
  arma::uword maxCO=0;
  for(arma::uword i=0; i<4; ++i){
    maxCO = std::max(maxCO, posCO(i).n_elem);
  }
  maxCO *= 2;
  output(0).set_size(maxCO+1,2);
  output(1).set_size(maxCO+1,2);
  
  // Select centromeres (which chromosome and chromatid)
  // Always taking chromosome 1 (1-4) and chromatid 1 (0-1) 
  arma::uvec chromosome(2, arma::fill::ones);
  arma::uvec chromatid(2, arma::fill::ones);
  chromosome(1) = alphasimrRng::sampleInt(1,3, rng)(0) + 2; // 2-4
  chromatid(1) = alphasimrRng::sampleInt(1,2, rng)(0); // 0-1
  
  // Find starting chromosomes and chromatids by working backwards
  // from selected centromeres to start of chromosome (head)
  arma::uword currentChromosome, currentChromatid;
  for(arma::uword i=0; i<2; ++i){
    // Identify starting chromosome and chromatid
    currentChromosome = chromosome(i);
    currentChromatid = chromatid(i);
    
    if(exchange>centromere){ // Centromere is in the head 
      
      if(currentChromosome<3){ // currentChromosome is 1 or 2
        
        // Loop through all chiasmata on arm 0
        for(arma::uword j=posCO(0).n_elem; j>0; --j){
          
          // Check if chiasmata is before centromere, ignore if not
          if(posCO(0)(j-1)<centromere){
            
            switch(currentChromosome){
            case 1: // Check if there's a switch between chr 1 and 2
              if(chromatidPairs(0)(j-1,0) == currentChromatid){
                currentChromosome = 2;
                currentChromatid = chromatidPairs(0)(j-1,1);
              }
              break;
            case 2: // Check if there is a switch between chr 2 and 1
              if(chromatidPairs(0)(j-1,1) == currentChromatid){
                currentChromosome = 1;
                currentChromatid = chromatidPairs(0)(j-1,0);
              }
            }
          }
        }
        
      }else{ // currentChromosome is 3 or 4
        
        // Loop through all chiasmata on arm 2
        for(arma::uword j=posCO(2).n_elem; j>0; --j){
          
          // Check if chiasmata is before centromere, ignore if not
          if(posCO(2)(j-1)<centromere){
            
            switch(currentChromosome){
            case 3: // Check if there's a switch between chr 3 and 4
              if(chromatidPairs(2)(j-1,0) == currentChromatid){
                currentChromosome = 4;
                currentChromatid = chromatidPairs(2)(j-1,1);
              }
              break;
            case 4: // Check if there's a switch between chr 4 and 3
              if(chromatidPairs(2)(j-1,1) == currentChromatid){
                currentChromosome = 3;
                currentChromatid = chromatidPairs(2)(j-1,0);
              }
            }
          }
        }
      }
      
    }else{ // Centromere is in the tail
      
      if((currentChromosome==1) | (currentChromosome==4)){ // Working on arm 3
        
        // Find chromosome and chromatid before transition by looping 
        // through chiasmata on arm 3
        for(arma::uword j=posCO(3).n_elem; j>0; --j){
          
          // Check if chiasmata is before centromere, ignore if not
          if(posCO(3)(j-1)<centromere){
            switch(currentChromosome){
            case 1: // Check if there's a switch between chr 1 and 4
              if(chromatidPairs(3)(j-1,0) == currentChromatid){
                currentChromosome = 4;
                currentChromatid = chromatidPairs(3)(j-1,1);
              }
              break;
            case 4: // Check if there's a switch between chr 4 and 1
              if(chromatidPairs(3)(j-1,1) == currentChromatid){
                currentChromosome = 1;
                currentChromatid = chromatidPairs(3)(j-1,0);
              }
            }
          }
        }
        
        // Find starting chromosome and chromatid by working back through head
        switch(currentChromosome){
        case 1: // Work through arm 0
          for(arma::uword j=posCO(0).n_elem; j>0; --j){
            switch(currentChromosome){
            case 1: // Check if there's a switch between chr 1 and 2
              if(chromatidPairs(0)(j-1,0) == currentChromatid){
                currentChromosome = 2;
                currentChromatid = chromatidPairs(0)(j-1,1);
              }
              break;
            case 2: // Check if there's a switch between chr 2 and 1
              if(chromatidPairs(0)(j-1,1) == currentChromatid){
                currentChromosome = 1;
                currentChromatid = chromatidPairs(0)(j-1,0);
              }
            }
          }
          break;
        case 4: // Work through arm 2
          for(arma::uword j=posCO(2).n_elem; j>0; --j){
            switch(currentChromosome){
            case 3: // Check if there's a switch between chr 3 and 4
              if(chromatidPairs(2)(j-1,0) == currentChromatid){
                currentChromosome = 4;
                currentChromatid = chromatidPairs(2)(j-1,1);
              }
              break;
            case 4: // Check if there's a switch between chr 4 and 3
              if(chromatidPairs(2)(j-1,1) == currentChromatid){
                currentChromosome = 3;
                currentChromatid = chromatidPairs(2)(j-1,0);
              }
            }
          }
        }
        
      }else{ // Working on arm 1
        
        // Find chromosome and chromatid before transition by looping 
        // through chiasmata on arm 1
        for(arma::uword j=posCO(1).n_elem; j>0; --j){
          
          // Check if chiasmata is before centromere, ignore if not
          if(posCO(1)(j-1)<centromere){
            switch(currentChromosome){
            case 2: // Check if there's a switch between chr 2 and 3
              if(chromatidPairs(1)(j-1,0) == currentChromatid){
                currentChromosome = 3;
                currentChromatid = chromatidPairs(1)(j-1,1);
              }
              break;
            case 3: // Check if there's a switch between chr 3 and 2
              if(chromatidPairs(1)(j-1,1) == currentChromatid){
                currentChromosome = 2;
                currentChromatid = chromatidPairs(1)(j-1,0);
              }
            }
          }
        }
        
        // Find starting chromosome and chromatid by working back through head
        switch(currentChromosome){
        case 2: // Work through arm 0
          for(arma::uword j=posCO(0).n_elem; j>0; --j){
            switch(currentChromosome){
            case 1: // Check if there's a switch between chr 1 and 2
              if(chromatidPairs(0)(j-1,0) == currentChromatid){
                currentChromosome = 2;
                currentChromatid = chromatidPairs(0)(j-1,1);
              }
              break;
            case 2: // Check if there's a switch between chr 2 and 1
              if(chromatidPairs(0)(j-1,1) == currentChromatid){
                currentChromosome = 1;
                currentChromatid = chromatidPairs(0)(j-1,0);
              }
            }
          }
          break;
        case 3: // Work through arm 2
          for(arma::uword j=posCO(2).n_elem; j>0; --j){
            switch(currentChromosome){
            case 3: // Check if there's a switch between chr 3 and 4
              if(chromatidPairs(2)(j-1,0) == currentChromatid){
                currentChromosome = 4;
                currentChromatid = chromatidPairs(2)(j-1,1);
              }
              break;
            case 4: // Check if there's a switch between chr 4 and 3
              if(chromatidPairs(2)(j-1,1) == currentChromatid){
                currentChromosome = 3;
                currentChromatid = chromatidPairs(2)(j-1,0);
              }
            }
          }
        }
      }
    }
    
    // Fill in crossover map by working from head to tail
    arma::uword startPos=0, endPos, nCO=0;
    output(i)(0,0) = currentChromosome;
    output(i)(0,1) = 1;
    
    if(currentChromosome<3){ // Start in arm 0
      
      // Fill crossovers in the head
      for(arma::uword j=0; j<posCO(0).n_elem; ++j){
        
        // Check if chiasmata involves current chromatid
        switch(currentChromosome){
        case 1: 
          if(chromatidPairs(0)(j,0) == currentChromatid){
            currentChromosome = 2;
            currentChromatid = chromatidPairs(0)(j,1);
            ++nCO;
            endPos = intervalSearch(genMap,posCO(0)(j),startPos);
            output(i)(nCO,0) = currentChromosome;
            output(i)(nCO,1) = endPos+2;
            startPos = endPos;
          }
          break;
        case 2:
          if(chromatidPairs(0)(j,1) == currentChromatid){
            currentChromosome = 1;
            currentChromatid = chromatidPairs(0)(j,0);
            ++nCO;
            endPos = intervalSearch(genMap,posCO(0)(j),startPos);
            output(i)(nCO,0) = currentChromosome;
            output(i)(nCO,1) = endPos+2;
            startPos = endPos;
          }
        }
      }
      
      // Fill crossovers in the tail
      if(currentChromosome==1){ // Move to arm 3
        for(arma::uword j=0; j<posCO(3).n_elem; ++j){
          switch(currentChromosome){
          case 1:
            if(chromatidPairs(3)(j,0) == currentChromatid){
              currentChromosome = 4;
              currentChromatid = chromatidPairs(3)(j,1);
              ++nCO;
              endPos = intervalSearch(genMap,posCO(3)(j),startPos);
              output(i)(nCO,0) = currentChromosome;
              output(i)(nCO,1) = endPos+2;
              startPos = endPos;
            }
            break;
          case 4:
            if(chromatidPairs(3)(j,1) == currentChromatid){
              currentChromosome = 1;
              currentChromatid = chromatidPairs(3)(j,0);
              ++nCO;
              endPos = intervalSearch(genMap,posCO(3)(j),startPos);
              output(i)(nCO,0) = currentChromosome;
              output(i)(nCO,1) = endPos+2;
              startPos = endPos;
            }
          }
        }
      }else{ // currentChromosome = 2, move to arm 1
        for(arma::uword j=0; j<posCO(1).n_elem; ++j){
          switch(currentChromosome){
          case 2:
            if(chromatidPairs(1)(j,0) == currentChromatid){
              currentChromosome = 3;
              currentChromatid = chromatidPairs(1)(j,1);
              ++nCO;
              endPos = intervalSearch(genMap,posCO(1)(j),startPos);
              output(i)(nCO,0) = currentChromosome;
              output(i)(nCO,1) = endPos+2;
              startPos = endPos;
            }
            break;
          case 3:
            if(chromatidPairs(1)(j,1) == currentChromatid){
              currentChromosome = 2;
              currentChromatid = chromatidPairs(1)(j,0);
              ++nCO;
              endPos = intervalSearch(genMap,posCO(1)(j),startPos);
              output(i)(nCO,0) = currentChromosome;
              output(i)(nCO,1) = endPos+2;
              startPos = endPos;
            }
          }
        }
      }
    }else{ // currentChromosome>2, start in arm 2
      
      // Fill crossovers in the head
      for(arma::uword j=0; j<posCO(2).n_elem; ++j){
        switch(currentChromosome){
        case 3:
          if(chromatidPairs(2)(j,0) == currentChromatid){
            currentChromosome = 4;
            currentChromatid = chromatidPairs(2)(j,1);
            ++nCO;
            endPos = intervalSearch(genMap,posCO(2)(j),startPos);
            output(i)(nCO,0) = currentChromosome;
            output(i)(nCO,1) = endPos+2;
            startPos = endPos;
          }
          break;
        case 4:
          if(chromatidPairs(2)(j,1) == currentChromatid){
            currentChromosome = 3;
            currentChromatid = chromatidPairs(2)(j,0);
            ++nCO;
            endPos = intervalSearch(genMap,posCO(2)(j),startPos);
            output(i)(nCO,0) = currentChromosome;
            output(i)(nCO,1) = endPos+2;
            startPos = endPos;
          }
        }
      }
      
      // Fill crossovers in the tail
      if(currentChromosome==4){ // Move to arm 3
        for(arma::uword j=0; j<posCO(3).n_elem; ++j){
          switch(currentChromosome){
          case 1:
            if(chromatidPairs(3)(j,0) == currentChromatid){
              currentChromosome = 4;
              currentChromatid = chromatidPairs(3)(j,1);
              ++nCO;
              endPos = intervalSearch(genMap,posCO(3)(j),startPos);
              output(i)(nCO,0) = currentChromosome;
              output(i)(nCO,1) = endPos+2;
              startPos = endPos;
            }
            break;
          case 4:
            if(chromatidPairs(3)(j,1) == currentChromatid){
              currentChromosome = 1;
              currentChromatid = chromatidPairs(3)(j,0);
              ++nCO;
              endPos = intervalSearch(genMap,posCO(3)(j),startPos);
              output(i)(nCO,0) = currentChromosome;
              output(i)(nCO,1) = endPos+2;
              startPos = endPos;
            }
          }
        }
      }else{ // currentChromosome = 3, move to arm 1
        for(arma::uword j=0; j<posCO(1).n_elem; ++j){
          switch(currentChromosome){
          case 2:
            if(chromatidPairs(1)(j,0) == currentChromatid){
              currentChromosome = 3;
              currentChromatid = chromatidPairs(1)(j,1);
              ++nCO;
              endPos = intervalSearch(genMap,posCO(1)(j),startPos);
              output(i)(nCO,0) = currentChromosome;
              output(i)(nCO,1) = endPos+2;
              startPos = endPos;
            }
            break;
          case 3:
            if(chromatidPairs(1)(j,1) == currentChromatid){
              currentChromosome = 2;
              currentChromatid = chromatidPairs(1)(j,0);
              ++nCO;
              endPos = intervalSearch(genMap,posCO(1)(j),startPos);
              output(i)(nCO,0) = currentChromosome;
              output(i)(nCO,1) = endPos+2;
              startPos = endPos;
            }
          }
        }
      }
    }
    output(i) = output(i).rows(arma::span(0,nCO));
    output(i) = removeDoubleCO(output(i));
  }
  
  return output;
}

void transferGeno(const arma::Col<unsigned char>& inChr,
                  arma::Col<unsigned char>& outChr,
                  int start,
                  int stop){
  start -= 1; // R to C++
  stop -= 1; // R to C++
  std::bitset<8> inBits, outBits;
  int startByte = start / 8;
  int stopByte = stop / 8;
  int startBit = start % 8;
  int stopBit = stop % 8;
  // Transfer partial start
  if(startBit != 0){
    inBits = toBits(inChr(startByte));
    outBits = toBits(outChr(startByte));
    if(stopByte > startByte){
      // Transferring more than this byte
      for(int i=startBit; i<8; ++i){
        outBits[i] = inBits[i];
      }
      outChr(startByte) = toByte(outBits);
      startBit = 0;
      ++startByte;
    }else{
      // Only transferring within this byte
      for(int i=startBit; i<stopBit; ++i){
        outBits[i] = inBits[i];
      }
      outChr(startByte) = toByte(outBits);
      return;
    }
  }
  // Transfer full bytes
  if(stopByte >  startByte){
    outChr(arma::span(startByte,stopByte-1)) = 
      inChr(arma::span(startByte,stopByte-1));
    startByte = stopByte;
  }
  // Transfer partial stop
  if(inChr.n_elem == static_cast<arma::uword>(startByte) ){
    // End has been reached
    return;
  }else{
    if(stopBit > startBit){
      inBits = toBits(inChr(startByte));
      outBits = toBits(outChr(startByte));
      for(int i = startBit; i<stopBit; ++i){
        outBits[i] = inBits[i];
      }
      outChr(startByte) = toByte(outBits);
    }
  }
}

// Simulates a gamete using a count-location model for recombination
// rng is the explicit dqrng stream used for crossover sampling and thinning.
void bivalent(const arma::Col<unsigned char>& chr1,
              const arma::Col<unsigned char>& chr2,
              const arma::vec& genMap,
              double v,
              double p,
              arma::Col<unsigned char>& output,
              arma::Mat<int>& hist,
              alphasimrRng::rngEngine& rng){
  hist = findBivalentCO(genMap, v, p, rng);
  if(hist.n_rows==1){
    output = chr1;
  }else{
    int nBins = chr1.n_elem;
    
    // Fill-in based on recombination history
    for(arma::uword i=0; i<(hist.n_rows-1); ++i){
      switch(hist(i,0)){
      case 1: //Chromosome 1
        transferGeno(chr1, output, 
                     hist(i,1), hist(i+1,1));
        break; 
      case 2: //Chromosome 2
        transferGeno(chr2, output, 
                     hist(i,1), hist(i+1,1));
      }
    }
    
    // Fill-in last sites
    switch(hist(hist.n_rows-1,0)){
    case 1:
      transferGeno(chr1, output, 
                   hist(hist.n_rows-1,1), 
                   nBins*8+1);
      break; 
    case 2:
      transferGeno(chr2, output, 
                   hist(hist.n_rows-1,1), 
                   nBins*8+1);
    }
  }
}

// Simulates a gamete using the existing discrete (bin-based) model for geno,
// AND also returns a continuous (genetic-coordinate) recombination history.
//
// - hist: int matrix (originChr, startSite/bin) used for transferGeno
// - histGen: double matrix (originChr, startPosGen) keeping all breakpoints
void bivalent2(const arma::Col<unsigned char>& chr1,
               const arma::Col<unsigned char>& chr2,
               const arma::vec& genMap,
               double v,
               double p,
               arma::Col<unsigned char>& output,
               arma::Mat<int>& hist,
               arma::Mat<double>& histGen,
               alphasimrRng::rngEngine& rng){

  arma::uword startPos = 0;
  arma::uword endPos;
  arma::uword readChr = 0;
  double genLen = genMap(genMap.n_elem - 1);

  // 1) Sample crossover positions once (shared)
  arma::vec posCO = sampleChiasmata(genLen, v, p, rng);

  // 2) Thin crossovers (same rule as original)
  if(posCO.n_elem > 0){
    arma::vec thin = alphasimrRng::runifVec(posCO.n_elem, rng);
    posCO = posCO(find(thin > 0.5));
  }

  // Ensure increasing order for intervalSearch and for histGen
  if(posCO.n_elem > 1){
    posCO = sort(posCO);
  }

  arma::uword nCO = posCO.n_elem;

  // 3) Build continuous history (keep all breakpoints)
  // Row 0 always starts from chr 1 at position 0.0
  histGen.set_size(nCO + 1, 2);
  histGen(0,0) = 1.0;
  histGen(0,1) = 0.0;

  readChr = 0;
  for(arma::uword i = 0; i < nCO; ++i){
    readChr = (readChr + 1) % 2;
    histGen(i + 1, 0) = double(readChr + 1);
    histGen(i + 1, 1) = posCO(i);
  }

  // 4) Build discrete history for transferGeno (may be simplified)
  // Match original convention: row0 is (1,1); later start sites use endPos+2
  arma::Mat<int> histRaw(nCO + 1, 2);
  histRaw(0,0) = 1;
  histRaw(0,1) = 1;

  if(nCO == 0){
    // No crossovers: single record is enough
    hist = histRaw;
    output = chr1;
    return;
  }

  readChr = 0;
  startPos = 0;
  for(arma::uword i = 0; i < nCO; ++i){
    readChr = (readChr + 1) % 2;
    double x = posCO(i);
    endPos = intervalSearch(genMap, x, startPos);
    histRaw(i + 1, 0) = int(readChr + 1);
    histRaw(i + 1, 1) = int(endPos + 2);
    startPos = endPos;
  }

  // Remove unobservable/redundant records for the discrete geno-transfer path only
  hist = removeDoubleCO(histRaw);

  // 5) Use the discrete history to transfer genotype bits (unchanged logic)
  int nBins = chr1.n_elem;

  if(hist.n_rows == 1){
    output = chr1;
    return;
  }

  for(arma::uword i = 0; i < (hist.n_rows - 1); ++i){
    switch(hist(i,0)){
      case 1:
        transferGeno(chr1, output, hist(i,1), hist(i+1,1));
        break;
      case 2:
        transferGeno(chr2, output, hist(i,1), hist(i+1,1));
        break;
    }
  }

  switch(hist(hist.n_rows - 1, 0)){
    case 1:
      transferGeno(chr1, output, hist(hist.n_rows - 1, 1), nBins*8 + 1);
      break;
    case 2:
      transferGeno(chr2, output, hist(hist.n_rows - 1, 1), nBins*8 + 1);
      break;
  }
}


// Simulates a gamete using the existing discrete (bin-based) model for geno,
// AND also returns a continuous (genetic-coordinate) recombination history.
//
// - hist: original int matrix (originChr, startSite/bin) used for transferGeno
// - histGen: new double matrix (originChr, startPosGen) with true breakpoints
void bivalent2Old(const arma::Col<unsigned char>& chr1,
               const arma::Col<unsigned char>& chr2,
               const arma::vec& genMap,
               double v,
               double p,
               arma::Col<unsigned char>& output,
               arma::Mat<int>& hist,
               // histGen added
               arma::Mat<double>& histGen,
               alphasimrRng::rngEngine& rng){

  hist = findBivalentCO(genMap, v, p, rng);

  // histGen added
  histGen = findBivalentCO_gen(genMap, v, p, rng);

  if(hist.n_rows==1){
    output = chr1;
  }else{
    int nBins = chr1.n_elem;

    for(arma::uword i=0; i<(hist.n_rows-1); ++i){
      switch(hist(i,0)){
        case 1:
          transferGeno(chr1, output, hist(i,1), hist(i+1,1));
          break;
        case 2:
          transferGeno(chr2, output, hist(i,1), hist(i+1,1));
      }
    }

    switch(hist(hist.n_rows-1,0)){
      case 1:
        transferGeno(chr1, output, hist(hist.n_rows-1,1), nBins*8+1);
        break;
      case 2:
        transferGeno(chr2, output, hist(hist.n_rows-1,1), nBins*8+1);
    }
  }
}

// Simulates a gamete using a count-location model for recombination
// rng is the explicit dqrng stream used for crossover sampling and thinning.
void quadrivalent(const arma::Col<unsigned char>& chr1,
                  const arma::Col<unsigned char>& chr2,
                  const arma::Col<unsigned char>& chr3,
                  const arma::Col<unsigned char>& chr4,
                  const arma::vec& genMap,
                  double centromere,
                  double v,
                  double p,
                  arma::Col<unsigned char>& output1,
                  arma::Col<unsigned char>& output2,
                  arma::Mat<int>& hist1,
                  arma::Mat<int>& hist2,
                  alphasimrRng::rngEngine& rng){
  int nBins = chr1.n_elem;
  
  arma::field<arma::Mat<int> > output;
  output = findQuadrivalentCO(genMap, centromere, v, p, rng);
  
  hist1 = output(0);
  hist2 = output(1);
  
  //Resolve first gamete
  if(hist1.n_rows==1){
    switch(hist1(0,0)){
    case 1:
      output1 = chr1;
      break;
    case 2:
      output1 = chr2;
      break;
    case 3:
      output1 = chr3;
      break;
    case 4:
      output1 = chr4;
    }
  }else{
    // Fill-in based on recombination history
    for(arma::uword i=0; i<(hist1.n_rows-1); ++i){
      switch(hist1(i,0)){
      case 1:
        transferGeno(chr1, output1, 
                     hist1(i,1), hist1(i+1,1));
        break;  
      case 2:
        transferGeno(chr2, output1, 
                     hist1(i,1), hist1(i+1,1));
        break;   
      case 3:
        transferGeno(chr3, output1, 
                     hist1(i,1), hist1(i+1,1));
        break;  
      case 4:
        transferGeno(chr4, output1, 
                     hist1(i,1), hist1(i+1,1));
      }
    }
    
    // Fill-in last sites
    switch(hist1(hist1.n_rows-1,0)){
    case 1:
      transferGeno(chr1, output1, 
                   hist1(hist1.n_rows-1,1), 
                   nBins*8+1);
      break;
    case 2:
      transferGeno(chr2, output1, 
                   hist1(hist1.n_rows-1,1), 
                   nBins*8+1);
      break;
    case 3:
      transferGeno(chr3, output1, 
                   hist1(hist1.n_rows-1,1), 
                   nBins*8+1);
      break;
    case 4:
      transferGeno(chr4, output1, 
                   hist1(hist1.n_rows-1,1), 
                   nBins*8+1);
    }
  }
  
  //Resolve second gamete
  if(hist2.n_rows==1){
    switch(hist2(0,0)){
    case 1:
      output2 = chr1;
      break;
    case 2:
      output2 = chr2;
      break;
    case 3:
      output2 = chr3;
      break;
    case 4:
      output2 = chr4;
    }
  }else{
    // Fill-in based on recombination history
    for(arma::uword i=0; i<(hist2.n_rows-1); ++i){
      switch(hist2(i,0)){
      case 1:
        transferGeno(chr1, output2, 
                     hist2(i,1), hist2(i+1,1));
        break;  
      case 2:
        transferGeno(chr2, output2, 
                     hist2(i,1), hist2(i+1,1));
        break; 
      case 3:
        transferGeno(chr3, output2, 
                     hist2(i,1), hist2(i+1,1));
        break;  
      case 4:
        transferGeno(chr4, output2, 
                     hist2(i,1), hist2(i+1,1));
      }
    }
    
    // Fill-in last sites
    switch(hist2(hist2.n_rows-1,0)){
    case 1:
      transferGeno(chr1, output2, 
                   hist2(hist2.n_rows-1,1), 
                   nBins*8+1);
      break; 
    case 2:
      transferGeno(chr2, output2, 
                   hist2(hist2.n_rows-1,1), 
                   nBins*8+1);
      break; 
    case 3:
      transferGeno(chr3, output2, 
                   hist2(hist2.n_rows-1,1), 
                   nBins*8+1);
      break; 
    case 4:
      transferGeno(chr4, output2, 
                   hist2(hist2.n_rows-1,1), 
                   nBins*8+1);
    }
  }
}

// Makes crosses between diploid individuals.
// motherGeno: female genotypes
// mother: female parents
// fatherGeno: male genotypes
// father: male parents
// femaleMap: chromosome genetic maps
// maleMap: chromosome genetic maps
// trackRec: track recombination
// motherPloidy: ploidy level of mother 
// fatherPloidy: ploidy level of father
// v: interference parameter for gamma model
// p: proportion of non-interfering crossovers
// quadProb: probability of quadrivalent formation
// nThreads: number of threads for parallel computing
// [[Rcpp::export]]
Rcpp::List cross(
    const arma::field<arma::Cube<unsigned char> >& motherGeno, 
    arma::uvec mother,
    const arma::field<arma::Cube<unsigned char> >& fatherGeno, 
    arma::uvec father,
    const arma::field<arma::vec>& femaleMap,
    const arma::field<arma::vec>& maleMap,
    bool trackRec,
    arma::uword motherPloidy,
    arma::uword fatherPloidy,
    double v,
    double p,
    const arma::vec& motherCentromere,
    const arma::vec& fatherCentromere,
    double quadProb,
    int nThreads,
    /* modified by Jinyang */
    bool trackRecGen){
  mother -= 1; // R to C++
  father -= 1; // R to C++
  arma::uword ploidy = (motherPloidy+fatherPloidy)/2;
  arma::uword nChr = motherGeno.n_elem;
  arma::uword nInd = mother.n_elem;
  //Output data
  arma::field<arma::Cube<unsigned char> > geno(nChr);
  RecHist hist;
  if(trackRec){
    hist.setSize(nInd,nChr,ploidy);
  }

  // modified by Jinyang
  RecHistDbl histGen;
  if(trackRecGen){
    histGen.setSize(nInd, nChr, ploidy);
  }

  if(nChr < static_cast<arma::uword>(nThreads) ){
    nThreads = nChr;
  }
  std::vector<alphasimrRng::rngPtr> chrRngs = makeChrRngs(nChr);
  //Loop through chromosomes
#ifdef _OPENMP
#pragma omp parallel for schedule(static) num_threads(nThreads)
#endif
  for(arma::uword chr=0; chr<nChr; ++chr){
    alphasimrRng::rngEngine& rng = *chrRngs[chr];
    arma::Mat<int> hist1, hist2;
    // modified by Jinyang
    arma::Mat<double> histG1, histG2;
    arma::uvec xm(motherPloidy); // Indicator for mother chromosomes
    for(arma::uword i=0; i<motherPloidy; ++i)
      xm(i) = i;
    arma::uvec xf(fatherPloidy); // Indicator for father chromosomes
    for(arma::uword i=0; i<fatherPloidy; ++i)
      xf(i) = i;
    arma::uword progenyChr;
    arma::uword nBins = motherGeno(chr).n_rows;
    arma::Cube<unsigned char> tmpGeno(nBins,ploidy,nInd);
    arma::Col<unsigned char> gamete1(nBins), gamete2(nBins);
    
    //Loop through individuals
    for(arma::uword ind=0; ind<nInd; ++ind){
      progenyChr=0;
      alphasimrRng::shuffle(xm, rng);
      
      //Female gamete
      for(arma::uword x=0; x<motherPloidy; x+=4){
        if((motherPloidy-x)>2){
          if(alphasimrRng::runif(rng)>quadProb){
            //Bivalent 1
            // modified by Jinyang ----
            if(trackRecGen){
              bivalent2(motherGeno(chr).slice(mother(ind)).col(xm(x)),
                        motherGeno(chr).slice(mother(ind)).col(xm(x+1)),
                        femaleMap(chr),
                        v,
                        p,
                        gamete1,
                        hist1,
                        histG1,
                        rng);
            } else {// ----modified by Jinyang
              bivalent(motherGeno(chr).slice(mother(ind)).col(xm(x)),
                       motherGeno(chr).slice(mother(ind)).col(xm(x+1)),
                       femaleMap(chr),
                       v,
                       p,
                       gamete1,
                       hist1,
                       rng);
            }
            tmpGeno.slice(ind).col(progenyChr) = gamete1;
            if(trackRec){
              hist1.col(0) *= 100; //To avoid conflicts
              hist1.col(0).replace(100,int(xm(x))+1);
              hist1.col(0).replace(200,int(xm(x+1))+1);
              hist.addHist(hist1,ind,chr,progenyChr);
            }
            // modified by Jinyang ----
            if(trackRecGen){
              // mirror the same origin remapping on histG1 (double)
              histG1.col(0) *= 100.0;
              histG1.col(0).replace(100.0, double(int(xm(x))+1));
              histG1.col(0).replace(200.0, double(int(xm(x+1))+1));
              histGen.addHist(histG1, ind, chr, progenyChr);
            }
            // ----modified by Jinyang
            ++progenyChr;
            
            //Bivalent 2
            // modified by Jinyang ----
            if(trackRecGen){
              bivalent2(motherGeno(chr).slice(mother(ind)).col(xm(x+2)),
                        motherGeno(chr).slice(mother(ind)).col(xm(x+3)),
                        femaleMap(chr),
                        v,
                        p,
                        gamete1,
                        hist1,
                        histG1,
                        rng);
            } else {
              // ----modified by Jinyang
              bivalent(motherGeno(chr).slice(mother(ind)).col(xm(x+2)),
                       motherGeno(chr).slice(mother(ind)).col(xm(x+3)),
                       femaleMap(chr),
                       v,
                       p,
                       gamete1,
                       hist1,
                       rng);
            }
            tmpGeno.slice(ind).col(progenyChr) = gamete1;
            if(trackRec){
              hist1.col(0) *= 100; //To avoid conflicts
              hist1.col(0).replace(100,int(xm(x+2))+1);
              hist1.col(0).replace(200,int(xm(x+3))+1);
              hist.addHist(hist1,ind,chr,progenyChr);
            }
            // modified by Jinyang ----
            if(trackRecGen){
              // mirror the same origin remapping on histG1 (double)
              histG1.col(0) *= 100.0;
              histG1.col(0).replace(100.0, double(int(xm(x+2))+1));
              histG1.col(0).replace(200.0, double(int(xm(x+3))+1));
              histGen.addHist(histG1, ind, chr, progenyChr);
            }
            // ----modified by Jinyang
            ++progenyChr;
          }else{
            //Quadrivalent
            quadrivalent(motherGeno(chr).slice(mother(ind)).col(xm(x)),
                         motherGeno(chr).slice(mother(ind)).col(xm(x+1)),
                         motherGeno(chr).slice(mother(ind)).col(xm(x+2)),
                         motherGeno(chr).slice(mother(ind)).col(xm(x+3)),
                         femaleMap(chr),
                         motherCentromere(chr),
                         v,
                         p,
                         gamete1,
                         gamete2,
                         hist1,
                         hist2,
                         rng);
            tmpGeno.slice(ind).col(progenyChr) = gamete1;
            tmpGeno.slice(ind).col(progenyChr+1) = gamete2;
            if(trackRec){
              hist1.col(0) *= 100; //To avoid conflicts
              hist1.col(0).replace(100,int(xm(x))+1);
              hist1.col(0).replace(200,int(xm(x+1))+1);
              hist.addHist(hist1,ind,chr,progenyChr);
              hist2.col(0) *= 100; //To avoid conflicts
              hist2.col(0).replace(100,int(xm(x+2))+1);
              hist2.col(0).replace(200,int(xm(x+3))+1);
              hist.addHist(hist2,ind,chr,progenyChr+1);
            }
            progenyChr += 2;
          }
        }else{
          //Bivalent
          // modified by Jinyang ----
          if(trackRecGen){
            bivalent2(motherGeno(chr).slice(mother(ind)).col(xm(x)),
                      motherGeno(chr).slice(mother(ind)).col(xm(x+1)),
                      femaleMap(chr),
                      v,
                      p,
                      gamete1,
                      hist1,
                      histG1,
                      rng);
          } else {
            // ----modified by Jinyang
            bivalent(motherGeno(chr).slice(mother(ind)).col(xm(x)),
                     motherGeno(chr).slice(mother(ind)).col(xm(x+1)),
                     femaleMap(chr),
                     v,
                     p,
                     gamete1,
                     hist1,
                     rng);
          }

          tmpGeno.slice(ind).col(progenyChr) = gamete1;
          if(trackRec){
            hist1.col(0) *= 100; //To avoid conflicts
            hist1.col(0).replace(100,int(xm(x))+1);
            hist1.col(0).replace(200,int(xm(x+1))+1);
            hist.addHist(hist1,ind,chr,progenyChr);
          }
          // modified by Jinyang ----
          if(trackRecGen){
            // mirror the same origin remapping on histG1 (double)
            histG1.col(0) *= 100.0;
            histG1.col(0).replace(100.0, double(int(xm(x))+1));
            histG1.col(0).replace(200.0, double(int(xm(x+1))+1));
            histGen.addHist(histG1, ind, chr, progenyChr);
          }
          // ----modified by Jinyang
          ++progenyChr;
        }
      }
      
      //Male gamete
      alphasimrRng::shuffle(xf, rng);
      for(arma::uword x=0; x<fatherPloidy; x+=4){
        if((fatherPloidy-x)>2){
          if(alphasimrRng::runif(rng)>quadProb){
            //Bivalent 1
            // modified by Jinyang ----
            if(trackRecGen){
              bivalent2(fatherGeno(chr).slice(father(ind)).col(xf(x)),
                        fatherGeno(chr).slice(father(ind)).col(xf(x+1)),
                        maleMap(chr),
                        v,
                        p,
                        gamete1,
                        hist1,
                        histG1,
                        rng);
            } else {
              // ----modified by Jinyang
              bivalent(fatherGeno(chr).slice(father(ind)).col(xf(x)),
                       fatherGeno(chr).slice(father(ind)).col(xf(x+1)),
                       maleMap(chr),
                       v,
                       p,
                       gamete1,
                       hist1,
                       rng);
            }
            tmpGeno.slice(ind).col(progenyChr) = gamete1;
            if(trackRec){
              hist1.col(0) *= 100; //To avoid conflicts
              hist1.col(0).replace(100,int(xf(x))+1);
              hist1.col(0).replace(200,int(xf(x+1))+1);
              hist.addHist(hist1,ind,chr,progenyChr);
            }
            // modified by Jinyang ----
            if(trackRecGen){
              // mirror the same origin remapping on histG1 (double)
              histG1.col(0) *= 100.0;
              histG1.col(0).replace(100.0, double(int(xf(x))+1));
              histG1.col(0).replace(200.0, double(int(xf(x+1))+1));
              histGen.addHist(histG1, ind, chr, progenyChr);
            }
            ++progenyChr;
            
            //Bivalent 2
            // modified by Jinyang ----
            if(trackRecGen){
              bivalent2(fatherGeno(chr).slice(father(ind)).col(xf(x+2)),
                        fatherGeno(chr).slice(father(ind)).col(xf(x+3)),
                        maleMap(chr),
                        v,
                        p,
                        gamete1,
                        hist1,
                        histG1,
                        rng);
            } else {
              // ----modified by Jinyang
              bivalent(fatherGeno(chr).slice(father(ind)).col(xf(x+2)),
                       fatherGeno(chr).slice(father(ind)).col(xf(x+3)),
                       maleMap(chr),
                       v,
                       p,
                       gamete1,
                       hist1,
                       rng);
            }
            tmpGeno.slice(ind).col(progenyChr) = gamete1;
            if(trackRec){
              hist1.col(0) *= 100; //To avoid conflicts
              hist1.col(0).replace(100,int(xf(x+2))+1);
              hist1.col(0).replace(200,int(xf(x+3))+1);
              hist.addHist(hist1,ind,chr,progenyChr);
            }
            // modified by Jinyang ----
            if(trackRecGen){
              // mirror the same origin remapping on histG1 (double)
              histG1.col(0) *= 100.0;
              histG1.col(0).replace(100.0, double(int(xf(x+2))+1));
              histG1.col(0).replace(200.0, double(int(xf(x+3))+1));
              histGen.addHist(histG1, ind, chr, progenyChr);
            }
            ++progenyChr;
          }else{
            //Quadrivalent
            quadrivalent(fatherGeno(chr).slice(father(ind)).col(xf(x)),
                         fatherGeno(chr).slice(father(ind)).col(xf(x+1)),
                         fatherGeno(chr).slice(father(ind)).col(xf(x+2)),
                         fatherGeno(chr).slice(father(ind)).col(xf(x+3)),
                         maleMap(chr),
                         fatherCentromere(chr),
                         v,
                         p,
                         gamete1,
                         gamete2,
                         hist1,
                         hist2,
                         rng);
            tmpGeno.slice(ind).col(progenyChr) = gamete1;
            tmpGeno.slice(ind).col(progenyChr+1) = gamete2;
            if(trackRec){
              hist1.col(0) *= 100; //To avoid conflicts
              hist1.col(0).replace(100,int(xf(x))+1);
              hist1.col(0).replace(200,int(xf(x+1))+1);
              hist.addHist(hist1,ind,chr,progenyChr);
              hist2.col(0) *= 100; //To avoid conflicts
              hist2.col(0).replace(100,int(xf(x+2))+1);
              hist2.col(0).replace(200,int(xf(x+3))+1);
              hist.addHist(hist2,ind,chr,progenyChr+1);
            }
            progenyChr += 2;
          }
        }else{
          //Bivalent
          // modified by Jinyang ----
          if(trackRecGen){
            bivalent2(fatherGeno(chr).slice(father(ind)).col(xf(x)),
                      fatherGeno(chr).slice(father(ind)).col(xf(x+1)),
                      maleMap(chr),
                      v,
                      p,
                      gamete1,
                      hist1,
                      histG1,
                      rng);
          } else {
            // ----modified by Jinyang
            bivalent(fatherGeno(chr).slice(father(ind)).col(xf(x)),
                     fatherGeno(chr).slice(father(ind)).col(xf(x+1)),
                     maleMap(chr),
                     v,
                     p,
                     gamete1,
                     hist1,
                     rng);
          }
          tmpGeno.slice(ind).col(progenyChr) = gamete1;
          if(trackRec){
            hist1.col(0) *= 100; //To avoid conflicts
            hist1.col(0).replace(100,int(xf(x))+1);
            hist1.col(0).replace(200,int(xf(x+1))+1);
            hist.addHist(hist1,ind,chr,progenyChr);
          }
          // modified by Jinyang ----
          if(trackRecGen){
            // mirror the same origin remapping on histG1 (double)
            histG1.col(0) *= 100.0;
            histG1.col(0).replace(100.0, double(int(xf(x))+1));
            histG1.col(0).replace(200.0, double(int(xf(x+1))+1));
            histGen.addHist(histG1, ind, chr, progenyChr);
          }
          ++progenyChr;
        }
      }
    } //End individual loop
    geno(chr) = tmpGeno;
  } //End chromosome loop

  // modified by Jinyang ----
  if(trackRec){
    if(trackRecGen){
      return Rcpp::List::create(Rcpp::Named("geno")=geno,
                                Rcpp::Named("recHist")=hist.hist,
                                Rcpp::Named("recHistGen")=histGen.hist);
    } else {
      return Rcpp::List::create(Rcpp::Named("geno")=geno,
                                Rcpp::Named("recHist")=hist.hist);
    }
  }
  return Rcpp::List::create(Rcpp::Named("geno")=geno);
}

// Creates DH lines from diploid individuals
// [[Rcpp::export]]
Rcpp::List createDH2(
    const arma::field<arma::Cube<unsigned char> >& geno, 
    arma::uword nDH, const arma::field<arma::vec>& genMap, 
    double v, double p, bool trackRec, int nThreads){
  arma::uword nChr = geno.n_elem;
  arma::uword nInd = geno(0).n_slices;
  //Output data
  arma::field<arma::Cube<unsigned char> > output(nChr);
  RecHist hist;
  if(trackRec){
    hist.setSize(nInd*nDH,nChr,2);
  }
  if(nChr < static_cast<arma::uword>(nThreads) ){
    nThreads = nChr;
  }
  std::vector<alphasimrRng::rngPtr> chrRngs = makeChrRngs(nChr);
#ifdef _OPENMP
#pragma omp parallel for schedule(static) num_threads(nThreads)
#endif
  for(arma::uword chr=0; chr<nChr; ++chr){ //Chromosome loop
    alphasimrRng::rngEngine& rng = *chrRngs[chr];
    arma::Mat<int> histMat;
    arma::uword nBins = geno(chr).n_rows;
    arma::Cube<unsigned char> tmp(nBins,2,nInd*nDH);
    arma::Col<unsigned char> gamete(nBins);
    arma::uvec x = {0,1};
    for(arma::uword ind=0; ind<nInd; ++ind){ //Individual loop
      for(arma::uword i=0; i<nDH; ++i){ //nDH loop
        alphasimrRng::shuffle(x, rng);
        bivalent(geno(chr).slice(ind).col(x(0)),
                 geno(chr).slice(ind).col(x(1)),
                 genMap(chr),
                 v,
                 p,
                 gamete,
                 histMat,
                 rng);
        for(arma::uword j=0; j<2; ++j){ //ploidy loop
          tmp.slice(i+ind*nDH).col(j) = gamete;
          if(trackRec){
            if((x(0)==1) & (j==0)){
              histMat.col(0).transform([](int val){return val%2+1;});
            }
            hist.addHist(histMat,i+ind*nDH,chr,j);
          }
        } //End ploidy loop
      } //End nDH loop
    } //End individual loop
    output(chr) = tmp;
  } //End chromosome loop
  if(trackRec){
    return Rcpp::List::create(Rcpp::Named("geno")=output,
                              Rcpp::Named("recHist")=hist.hist);
  }
  return Rcpp::List::create(Rcpp::Named("geno")=output);
}

// Samples gametes from individuals
// [[Rcpp::export]]
Rcpp::List createReducedGenome(
    const arma::field<arma::Cube<unsigned char> >& geno, 
    arma::uword nProgeny, const arma::field<arma::vec>& genMap, 
    double v, double p, bool trackRec, arma::uword ploidy,  
    arma::vec& centromere, double quadProb, int nThreads){
  arma::uword nChr = geno.n_elem;
  arma::uword nInd = geno(0).n_slices;
  //Output data
  arma::field<arma::Cube<unsigned char> > output(nChr);
  RecHist hist;
  if(trackRec){
    hist.setSize(nInd*nProgeny,nChr,ploidy/2);
  }
  if(nChr < static_cast<arma::uword>(nThreads) ){
    nThreads = nChr;
  }
  std::vector<alphasimrRng::rngPtr> chrRngs = makeChrRngs(nChr);
#ifdef _OPENMP
#pragma omp parallel for schedule(static) num_threads(nThreads)
#endif
  for(arma::uword chr=0; chr<nChr; ++chr){ //Chromosome loop
    alphasimrRng::rngEngine& rng = *chrRngs[chr];
    arma::Mat<int> hist1, hist2;
    arma::uword nBins = geno(chr).n_rows;
    arma::Cube<unsigned char> tmpGeno(nBins,ploidy/2,nInd*nProgeny);
    arma::Col<unsigned char> gamete1(nBins), gamete2(nBins);
    arma::uvec x(ploidy);
    for(arma::uword i=0; i<ploidy; ++i) 
      x(i) = i;
    for(arma::uword ind=0; ind<(nInd*nProgeny); ++ind){ //Individual loop
      alphasimrRng::shuffle(x, rng);
      arma::uword progenyChr=0;
      arma::uword par = ind/nProgeny;
      for(arma::uword y=0; y<ploidy; y+=4){
        if((ploidy-y)>2){
          if(alphasimrRng::runif(rng)>quadProb){
            //Bivalent 1
            bivalent(geno(chr).slice(par).col(x(y)),
                     geno(chr).slice(par).col(x(y+1)),
                     genMap(chr),
                     v,
                     p,
                     gamete1,
                     hist1,
                     rng);
            tmpGeno.slice(ind).col(progenyChr) = gamete1;
            if(trackRec){
              hist1.col(0) *= 100; //To avoid conflicts
              hist1.col(0).replace(100,int(x(y))+1);
              hist1.col(0).replace(200,int(x(y+1))+1);
              hist.addHist(hist1,ind,chr,progenyChr);
            }
            ++progenyChr;
            
            //Bivalent 2
            bivalent(geno(chr).slice(par).col(x(y+2)),
                     geno(chr).slice(par).col(x(y+3)),
                     genMap(chr),
                     v,
                     p,
                     gamete1,
                     hist1,
                     rng);
            tmpGeno.slice(ind).col(progenyChr) = gamete1;
            if(trackRec){
              hist1.col(0) *= 100; //To avoid conflicts
              hist1.col(0).replace(100,int(x(y+2))+1);
              hist1.col(0).replace(200,int(x(y+3))+1);
              hist.addHist(hist1,ind,chr,progenyChr);
            }
            ++progenyChr;
          }else{
            //Quadrivalent
            quadrivalent(geno(chr).slice(par).col(x(y)),
                         geno(chr).slice(par).col(x(y+1)),
                         geno(chr).slice(par).col(x(y+2)),
                         geno(chr).slice(par).col(x(y+3)),
                         genMap(chr),
                         centromere(chr),
                         v,
                         p,
                         gamete1,
                         gamete2,
                         hist1,
                         hist2,
                         rng);
            tmpGeno.slice(ind).col(progenyChr) = gamete1;
            tmpGeno.slice(ind).col(progenyChr+1) = gamete2;
            if(trackRec){
              hist1.col(0) *= 100; //To avoid conflicts
              hist1.col(0).replace(100,int(x(y))+1);
              hist1.col(0).replace(200,int(x(y+1))+1);
              hist.addHist(hist1,ind,chr,progenyChr);
              hist2.col(0) *= 100; //To avoid conflicts
              hist2.col(0).replace(100,int(x(y+2))+1);
              hist2.col(0).replace(200,int(x(y+3))+1);
              hist.addHist(hist2,ind,chr,progenyChr+1);
            }
            progenyChr += 2;
          }
        }else{
          //Bivalent
          bivalent(geno(chr).slice(par).col(x(y)),
                   geno(chr).slice(par).col(x(y+1)),
                   genMap(chr),
                   v,
                   p,
                   gamete1,
                   hist1,
                   rng);
          tmpGeno.slice(ind).col(progenyChr) = gamete1;
          if(trackRec){
            hist1.col(0) *= 100; //To avoid conflicts
            hist1.col(0).replace(100,int(x(y))+1);
            hist1.col(0).replace(200,int(x(y+1))+1);
            hist.addHist(hist1,ind,chr,progenyChr);
          }
          ++progenyChr;
        }
      } // End ploidy loop
    } // End individual loop
    output(chr) = tmpGeno;
  } //End chromosome loop
  if(trackRec){
    return Rcpp::List::create(Rcpp::Named("geno")=output,
                              Rcpp::Named("recHist")=hist.hist);
  }
  return Rcpp::List::create(Rcpp::Named("geno")=output);
}
